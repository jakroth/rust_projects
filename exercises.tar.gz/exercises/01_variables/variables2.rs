fn main() {
    // TODO: Change the line below to fix the compiler error.
    let x = 5;

    if x == 10 {
        println!("x is ten!");
    } else {
        println!("x is not ten!");
    }
}
