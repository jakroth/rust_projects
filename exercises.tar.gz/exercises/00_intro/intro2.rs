fn main() {
    // TODO: Fix the code to print "Hello world!".
    println!("Hello world!");
}
